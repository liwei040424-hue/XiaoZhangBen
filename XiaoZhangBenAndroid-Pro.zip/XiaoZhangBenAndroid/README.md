# 小账本 Android 项目（源代码）

这是一个 Android Studio 项目骨架，将小账本网页放进 Android WebView，启动后显示为独立 App。

## 构建 APK
1. 在电脑安装 Android Studio（建议使用包含 Android SDK 的最新版）。
2. 用 Android Studio 打开本目录 `XiaoZhangBenAndroid`。
3. 等待 Gradle 同步，并安装 Android SDK Platform 35（如提示）。
4. 选择 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。
5. 成功后 APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 当前版本说明
- 应用名称：小账本；包名：`com.xiaozhangben.app`。
- 记账和投资数据使用 WebView 本地存储，保存在本应用的数据目录内。
- 现有功能包括日常收支、多币种手动汇率、资产持仓、手动更新报价、买卖/股息记录、JSON 备份和 CSV 导出。
- 暂无自动股票行情 API、云同步、加密数据库或多设备同步。
- 这是可构建的源项目，不是已编译、签名并在真机测试过的 APK。首次构建需要 Android Studio/SDK。

## Build APK in the cloud (no computer with Android Studio required)

1. On your phone, create/sign in to a GitHub account and create a **private** repository (for example `XiaoZhangBen`).
2. Upload the contents of this project folder to the repository's root, including the `.github/workflows/build-apk.yml` file. Make sure the file is located at `.github/workflows/build-apk.yml` in the repository.
3. Open the repository's **Actions** tab. If prompted, enable workflows. Select **Build Android APK** and tap **Run workflow** (or push to the `main` branch to trigger it automatically).
4. Wait for the workflow to finish with a green check. Open that workflow run and download the artifact named **XiaoZhangBen-debug-apk**.
5. Extract the downloaded artifact ZIP on your phone; it contains `app-debug.apk`. Open it to install. Android may ask you to allow installs from that browser or file manager; only enable this for the app you trust, then turn it off again if desired.

This produces a **debug APK** signed with the build system's debug key. It is suitable for personal testing, not a Play Store release. GitHub account UI may vary on mobile. Do not upload personal finance records to the repository; the repository contains app source only. The app stores its records locally on the device and has no cloud sync.


## 本次更新：完整备份与储蓄税后收益估算

- 设置页可导出完整 JSON 备份，包含账户、流水、预算、投资、汇率和缓存的 CDI/Selic 基准利率；可从 JSON 备份导入恢复。导入会覆盖当前数据，请先导出备份。
- 储蓄账户可选择税务规则：巴西 RDB/CDB（按持有期 IR 递减税率估算，并估算 30 天内 IOF）、符合条件的免税产品或不计算税费。
- 储蓄页面显示 30 天及 365 天毛利息、估算 IR、IOF 和净利息。
- 这是基于当前余额和利率的预测，不是按每笔存款批次计算的银行对账结果；实际 Nu 产品类型、赎回日期、税务和计息方式应以产品账单为准。
