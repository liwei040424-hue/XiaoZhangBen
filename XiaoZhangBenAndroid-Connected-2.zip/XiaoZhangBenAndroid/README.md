# 小账本 Android 项目（源代码）

这是一个 Android Studio 项目骨架，将小账本网页放进 Android WebView，启动后显示为独立 App。

## 构建 APK
1. 在电脑安装 Android Studio（建议使用包含 Android SDK 的最新版）。
2. 用 Android Studio 打开本目录 `XiaoZhangBenAndroid`。
3. 等待 Gradle 同步，并安装 Android SDK Platform 35（如提示）。
4. 选择 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。
5. 成功后 APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 当前版本说明
- 应用名称：小账本；包名：`com.xiaozhangben.app`。
- 记账和投资数据使用 WebView 本地存储，保存在本应用的数据目录内。
- 现有功能包括日常收支、多币种手动汇率、资产持仓、手动更新报价、买卖/股息记录、JSON 备份和 CSV 导出。
- 暂无自动股票行情 API、云同步、加密数据库或多设备同步。
- 这是可构建的源项目，不是已编译、签名并在真机测试过的 APK。首次构建需要 Android Studio/SDK。

## Build APK in the cloud (no computer with Android Studio required)

1. On your phone, create/sign in to a GitHub account and create a **private** repository (for example `XiaoZhangBen`).
2. Upload the contents of this project folder to the repository's root, including the `.github/workflows/build-apk.yml` file. Make sure the file is located at `.github/workflows/build-apk.yml` in the repository.
3. Open the repository's **Actions** tab. If prompted, enable workflows. Select **Build Android APK** and tap **Run workflow** (or push to the `main` branch to trigger it automatically).
4. Wait for the workflow to finish with a green check. Open that workflow run and download the artifact named **XiaoZhangBen-debug-apk**.
5. Extract the downloaded artifact ZIP on your phone; it contains `app-debug.apk`. Open it to install. Android may ask you to allow installs from that browser or file manager; only enable this for the app you trust, then turn it off again if desired.

This produces a **debug APK** signed with the build system's debug key. It is suitable for personal testing, not a Play Store release. GitHub account UI may vary on mobile. Do not upload personal finance records to the repository; the repository contains app source only. The app stores its records locally on the device and has no cloud sync.


## 本次更新：完整备份与储蓄税后收益估算

- 设置页可导出完整 JSON 备份，包含账户、流水、预算、投资、汇率和缓存的 CDI/Selic 基准利率；可从 JSON 备份导入恢复。导入会覆盖当前数据，请先导出备份。
- 储蓄账户可选择税务规则：巴西 RDB/CDB（按持有期 IR 递减税率估算，并估算 30 天内 IOF）、符合条件的免税产品或不计算税费。
- 储蓄页面显示 30 天及 365 天毛利息、估算 IR、IOF 和净利息。
- 这是基于当前余额和利率的预测，不是按每笔存款批次计算的银行对账结果；实际 Nu 产品类型、赎回日期、税务和计息方式应以产品账单为准。


## 美股 / ETF 行情自动更新（免费优先）

- 数据源：Alpha Vantage 官方 `TIME_SERIES_DAILY` API，显示最近交易日收盘价，不是盘中实时或 15 分钟延迟行情。
- 需要用户自行免费申请 API Key，并在 App 的“投资组合”页保存；Key 存在本机 WebView localStorage，不写入源码或 JSON 备份。
- 免费 API 目前标示每天 25 次请求；应用本机按自然日计数并限制在 25 次，按至少 12.5 秒间隔发起请求以避免触及每分钟速率限制。额度记录只在本机，换设备或清除应用数据后不代表服务商实际额度。
- 只更新计价币种为 USD、且代码格式符合美股/ETF ticker 规则的资产。成功后更新现价，并保存行情日期与获取时间；失败时保留旧价格并显示错误。
- App 打开时，如果报价超过 6 小时会自动检查更新；App 在后台或关闭时不会保证定时刷新。也可手动点击“立即刷新行情”。
- API 免费额度、数据覆盖和使用许可可能调整；请以 Alpha Vantage 官方文档与账户页面为准。此功能未经真实 API Key 的端到端联网测试。

## 本次更新：联网汇率、网络状态与云端备份

### 汇率
- 数据源：Frankfurter 公共 API（基于欧洲央行参考汇率），无需 API Key；应用请求 USD→BRL 与 USD→CNY，再换算为 CNY→BRL。
- 手动点击“联网更新汇率”；不是实时外汇报价，工作日更新为主。失败时保留本机汇率，离线记账仍可用。
- API 说明：https://www.frankfurter.app/docs/

### 巴西 CDI / Selic
- 沿用巴西央行 BCB SGS 公共 API：SGS 系列 12（CDI）和 432（Selic 目标）。无需 API Key。App 启动时尝试更新，也可手动刷新。
- 公共服务可能限流或暂时不可用；失败时应使用缓存值，不应把缓存误认为实时值。

### 云端备份：Supabase（需要用户创建并配置）
云备份不是无需设置就自动可用。免费额度、项目休眠策略和服务条款可能变化，请以 Supabase 当前控制台为准。操作步骤：
1. 在 https://supabase.com 创建项目，复制 Project URL 与 anon/publishable key；**绝不要在 App 中使用 `service_role` / secret key**。
2. 在 Supabase SQL Editor 执行下方 SQL，创建备份表。该简化配置不启用公开访问，未配置认证的客户端将无法读写；请继续完成第 3 步。
3. 目前 App 使用匿名 Key 和用户自设备份标识，不等同于强身份认证。为了能在不同设备恢复，若开启 anon 角色访问，任何知道表名和备份标识且能访问项目 API 的人都可能尝试访问备份。建议只存非敏感测试数据，或先不要启用云备份；正式使用应改为 Supabase Auth 用户登录并用 `auth.uid()` 绑定备份所有权。
4. 在 App 设置页填写项目 URL、anon/publishable Key、备份标识，保存后可手动上传或恢复。恢复会覆盖本机账本，执行前请导出本地 JSON。

```sql
create table if not exists public.xzb_backups (
  backup_id text primary key,
  payload jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.xzb_backups enable row level security;
```

**重要安全限制：**当前客户端云备份为便于个人测试的基础版本，尚未集成用户登录、端到端加密或设备级密钥管理。仅设置 anon Key 和随机备份标识不能视为安全的私人云盘。不要上传身份证件、密码、银行登录资料等敏感信息；使用前应配置严格的 RLS 策略。应用会把云端设置保存在本机 WebView localStorage，API Key 不进入 JSON 备份，但 localStorage 并非加密保险箱。

### 网络状态与离线模式
- 设置页可手动检查网络连通性；各数据模块会单独显示请求成功/失败原因。
- 离线时仍可记账、查看本机已有数据、导出 JSON/CSV；联网功能失败不会自动清空本地数据。
- 目前没有保证后台自动同步；行情与汇率以手动触发/应用打开时的更新为主。

### 免费额度和刷新频率概览
| 功能 | 数据源 | API Key | 频率/限制 |
|---|---|---|---|
| 美股/ETF日线收盘价 | Alpha Vantage | 需要 | 免费额度当前为每天 25 次请求；本机最多按 25 次计数；每代码至少间隔约 12.5 秒；非实时 |
| CDI/Selic | 巴西央行 BCB SGS | 不需要 | 公共 API，无应用内付费额度保证；启动/手动刷新，可能限流 |
| USD/BRL、CNY/BRL | Frankfurter / ECB 参考汇率 | 不需要 | 公共 API，通常按工作日更新；手动刷新，非实时 |
| 云备份/恢复 | Supabase | 需要项目 URL 与客户端 Key | 取决于当前免费计划、数据库与 API 使用限制；需要用户配置 RLS/认证 |

以上为源码实现说明；未使用真实 API Key 做完整端到端验证，也未声称 APK 已成功构建。建议先用测试账本验证云备份和恢复，再放入真实数据。
