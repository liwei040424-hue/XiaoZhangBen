package com.xiaozhangben.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(android.graphics.Color.rgb(18, 37, 31));
        window.setNavigationBarColor(android.graphics.Color.rgb(18, 37, 31));
        window.getDecorView().setSystemUiVisibility(0);

        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(243, 245, 242));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new BcbBridge(), "AndroidBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class BcbBridge {
        @JavascriptInterface
        public String fetchAlphaVantageDaily(String symbol, String apiKey) {
            if (symbol == null || !symbol.matches("[A-Za-z][A-Za-z0-9.-]{0,9}")) return "{\"Error Message\":\"Invalid ticker symbol\"}";
            if (apiKey == null || !apiKey.matches("[A-Za-z0-9_-]{8,100}")) return "{\"Error Message\":\"Invalid API key format\"}";
            HttpURLConnection connection = null;
            try {
                String encodedSymbol = java.net.URLEncoder.encode(symbol.toUpperCase(java.util.Locale.US), "UTF-8");
                String encodedKey = java.net.URLEncoder.encode(apiKey, "UTF-8");
                URL url = new URL("https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=" + encodedSymbol + "&outputsize=compact&apikey=" + encodedKey);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(15000);
                connection.setReadTimeout(15000);
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("User-Agent", "XiaoZhangBen-Android/1.1");
                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                if (stream == null) return "{\"Error Message\":\"HTTP request failed\"}";
                StringBuilder result = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) result.append(line);
                }
                if (status < 200 || status >= 300) return "{\"Error Message\":\"HTTP " + status + "\"}";
                return result.toString();
            } catch (Exception e) {
                String msg = e.getMessage() == null ? "Network error" : e.getMessage().replace("\\", "\\\\").replace("\"", "\\\"");
                return "{\"Error Message\":\"" + msg + "\"}";
            } finally {
                if (connection != null) connection.disconnect();
            }
        }

        @JavascriptInterface
        public String fetchBcbSeries(int code) {
            if (code != 12 && code != 432) return "[]";
            HttpURLConnection connection = null;
            try {
                URL url = new URL("https://api.bcb.gov.br/dados/serie/bcdata.sgs." + code + "/dados/ultimos/1?formato=json");
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                connection.setRequestProperty("Accept", "application/json");
                int status = connection.getResponseCode();
                InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                if (stream == null) return "[]";
                StringBuilder result = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) result.append(line);
                }
                if (status < 200 || status >= 300) return "[]";
                return result.toString();
            } catch (Exception e) {
                return "[]";
            } finally {
                if (connection != null) connection.disconnect();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
